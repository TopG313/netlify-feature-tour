# AI Wealth Dashboard (Manual Deploy)
To deploy your dashboard:
1. Visit https://app.netlify.com and sign up/log in.
2. Drag & drop this folder into a new Netlify site to go live.
3. Your affiliate ID is embedded in the code.
